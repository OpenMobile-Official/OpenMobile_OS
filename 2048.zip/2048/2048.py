import pygame
import sys
import random
from modules.top_bar import TopBarManager

# --- Constants ---
SCREEN_WIDTH, SCREEN_HEIGHT = 480, 320
GRID_SIZE = 4
CELL_PADDING = 10
TOPBAR_HEIGHT = 50
BOARD_MARGIN = 20

# Colors
BG_COLOR = (187, 173, 160)
EMPTY_COLOR = (205, 193, 180)
CELL_COLORS = {
    2: (238, 228, 218),
    4: (237, 224, 200),
    8: (242, 177, 121),
    16: (245, 149, 99),
    32: (246, 124, 95),
    64: (246, 94, 59),
    128: (237, 207, 114),
    256: (237, 204, 97),
    512: (237, 200, 80),
    1024: (237, 197, 63),
    2048: (237, 194, 46),
}
TEXT_COLOR = (119, 110, 101)
FONT_COLOR = (255, 255, 255)

# --- Game Functions ---
def init_board():
    board = [[0]*GRID_SIZE for _ in range(GRID_SIZE)]
    add_random(board)
    add_random(board)
    return board

def add_random(board):
    empty = [(r, c) for r in range(GRID_SIZE) for c in range(GRID_SIZE) if board[r][c]==0]
    if empty:
        r, c = random.choice(empty)
        board[r][c] = 2 if random.random() < 0.9 else 4

def can_move(board):
    for r in range(GRID_SIZE):
        for c in range(GRID_SIZE):
            if board[r][c] == 0:
                return True
            if c < GRID_SIZE-1 and board[r][c] == board[r][c+1]:
                return True
            if r < GRID_SIZE-1 and board[r][c] == board[r+1][c]:
                return True
    return False

def compress(row):
    new_row = [i for i in row if i!=0]
    new_row += [0]*(GRID_SIZE - len(new_row))
    return new_row

def merge(row):
    score = 0
    for i in range(GRID_SIZE-1):
        if row[i] != 0 and row[i] == row[i+1]:
            row[i] *= 2
            row[i+1] = 0
            score += row[i]
    return row, score

def move_left(board):
    new_board = []
    score = 0
    for row in board:
        compressed = compress(row)
        merged, s = merge(compressed)
        score += s
        new_board.append(compress(merged))
    return new_board, score

def move_right(board):
    reversed_board = [row[::-1] for row in board]
    moved, score = move_left(reversed_board)
    return [row[::-1] for row in moved], score

def move_up(board):
    transposed = [list(row) for row in zip(*board)]
    moved, score = move_left(transposed)
    return [list(row) for row in zip(*moved)], score

def move_down(board):
    transposed = [list(row) for row in zip(*board)]
    reversed_rows = [row[::-1] for row in transposed]
    moved, score = move_left(reversed_rows)
    restored = [row[::-1] for row in moved]
    return [list(row) for row in zip(*restored)], score

# --- Main ---
def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("2048 Touch + Keyboard")

    font_small = pygame.font.SysFont("Arial", 16)
    font_medium = pygame.font.SysFont("Arial", 24, bold=True)
    font_large = pygame.font.SysFont("Arial", 36, bold=True)

    topbar = TopBarManager(SCREEN_WIDTH, SCREEN_HEIGHT, font_small, font_medium, app_key="2048")

    clock = pygame.time.Clock()

    board = init_board()
    score = 0

    swipe_start = None
    swipe_threshold = 30  # minimal swipe distance to register

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            topbar.handle_event(event)

            # --- Touch / Swipe Controls ---
            if event.type == pygame.MOUSEBUTTONDOWN:
                if event.button == 1:
                    swipe_start = event.pos
                    mouse_clicked = True
            elif event.type == pygame.MOUSEBUTTONUP:
                if swipe_start:
                    dx = event.pos[0] - swipe_start[0]
                    dy = event.pos[1] - swipe_start[1]

                    moved = False
                    s = 0

                    if abs(dx) > abs(dy) and abs(dx) > swipe_threshold:
                        if dx > 0:
                            board, s = move_right(board)
                        else:
                            board, s = move_left(board)
                        moved = True
                    elif abs(dy) > swipe_threshold:
                        if dy > 0:
                            board, s = move_down(board)
                        else:
                            board, s = move_up(board)
                        moved = True

                    if moved:
                        score += s
                        add_random(board)
                    swipe_start = None

            # --- Keyboard Controls ---
            elif event.type == pygame.KEYDOWN:
                moved = False
                s = 0
                if event.key == pygame.K_LEFT:
                    board, s = move_left(board)
                    moved = True
                elif event.key == pygame.K_RIGHT:
                    board, s = move_right(board)
                    moved = True
                elif event.key == pygame.K_UP:
                    board, s = move_up(board)
                    moved = True
                elif event.key == pygame.K_DOWN:
                    board, s = move_down(board)
                    moved = True

                if moved:
                    score += s
                    add_random(board)

        topbar.update()

        # --- Draw ---
        screen.fill(BG_COLOR)

        # Draw board
        board_size = SCREEN_HEIGHT - TOPBAR_HEIGHT - 2*BOARD_MARGIN
        cell_size = (board_size - CELL_PADDING*(GRID_SIZE+1)) / GRID_SIZE
        start_x = (SCREEN_WIDTH - board_size) / 2
        start_y = TOPBAR_HEIGHT + BOARD_MARGIN

        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                value = board[r][c]
                rect = pygame.Rect(
                    start_x + CELL_PADDING + c*(cell_size + CELL_PADDING),
                    start_y + CELL_PADDING + r*(cell_size + CELL_PADDING),
                    cell_size,
                    cell_size
                )
                pygame.draw.rect(screen, CELL_COLORS.get(value, EMPTY_COLOR), rect, border_radius=6)
                if value != 0:
                    text_surf = font_large.render(str(value), True, TEXT_COLOR if value <= 4 else FONT_COLOR)
                    text_rect = text_surf.get_rect(center=rect.center)
                    screen.blit(text_surf, text_rect)

        # Draw score
        score_surf = font_medium.render(f"Score: {score}", True, (255, 255, 0))
        screen.blit(score_surf, (10, TOPBAR_HEIGHT - 35))

        # Game over check
        if not can_move(board):
            over_surf = font_medium.render("Game Over!", True, (255, 50, 50))
            screen.blit(over_surf, (SCREEN_WIDTH//2 - over_surf.get_width()//2, SCREEN_HEIGHT//2 - 20))

        topbar.draw(screen)
        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
