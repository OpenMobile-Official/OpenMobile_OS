import pygame
import sys
import os
from modules.top_bar import TopBarManager
from modules.keyboard import run_keyboard

SAVE_FILE = "expenses.txt"

def load_expenses():
    expenses = []
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) == 2:
                    desc, amount = parts
                    try:
                        expenses.append([desc, float(amount)])
                    except ValueError:
                        pass
    return expenses

def save_expenses(expenses):
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        for desc, amount in expenses:
            f.write(f"{desc}|{amount}\n")

def main():
    pygame.init()
    screen_width, screen_height = 480, 320
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Expense Tracker")

    font_small = pygame.font.SysFont("Arial", 16)
    font_medium = pygame.font.SysFont("Arial", 22)
    font_title = pygame.font.SysFont("Arial", 26, bold=True)

    topbar = TopBarManager(screen_width, screen_height, font_small, font_medium, app_key="expenseapp")

    clock = pygame.time.Clock()

    # Button properties
    button_width = 180
    button_height = 50
    button_x = 20
    button_y = 80
    add_button_rect = pygame.Rect(button_x, button_y, button_width, button_height)
    button_font = pygame.font.SysFont("Arial", 22)

    # Expense storage
    expenses = load_expenses()
    scroll_offset = 0

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            topbar.handle_event(event)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_clicked = True

            # Scroll expenses with mouse wheel
            if event.type == pygame.MOUSEWHEEL:
                scroll_offset += event.y * 20
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(expenses)*25 - 160))

            # Touch drag scrolling
            if event.type == pygame.MOUSEMOTION and event.buttons[0]:
                scroll_offset += event.rel[1]
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(expenses)*25 - 160))

        topbar.update()

        # Background
        screen.fill((30, 30, 40))

        # Title
        title_surf = font_title.render("💰 Expense Tracker", True, (255, 255, 255))
        screen.blit(title_surf, (20, 20))

        # Add Expense button
        pygame.draw.rect(screen, (70, 130, 180), add_button_rect, border_radius=8)
        if add_button_rect.collidepoint(mouse_pos) and mouse_clicked:
            # Step 1: ask for description
            desc = run_keyboard()
            if desc.strip():
                # Step 2: ask for amount
                amount_text = run_keyboard()
                try:
                    amount = float(amount_text.strip())
                    expenses.append([desc.strip(), amount])
                    save_expenses(expenses)
                except ValueError:
                    pass  # ignore invalid numbers

        text_surf = button_font.render("Add Expense", True, (255, 255, 255))
        text_rect = text_surf.get_rect(center=add_button_rect.center)
        screen.blit(text_surf, text_rect)

        # Expenses panel (right side)
        panel_x = 220
        panel_y = 80
        panel_width = screen_width - panel_x - 20
        panel_height = screen_height - panel_y - 20
        panel_rect = pygame.Rect(panel_x, panel_y, panel_width, panel_height)
        pygame.draw.rect(screen, (50, 50, 70), panel_rect, border_radius=6)

        # Clip drawing to panel
        screen.set_clip(panel_rect)

        # Display expenses (scrollable)
        history_y = panel_y + 10 + scroll_offset
        total = 0
        for i, (desc, amount) in enumerate(expenses):
            total += amount
            exp_text = f"{i+1}. {desc} - ${amount:.2f}"
            exp_surf = font_small.render(exp_text, True, (230, 230, 230))
            screen.blit(exp_surf, (panel_x + 10, history_y))
            history_y += 22

        # Reset clipping
        screen.set_clip(None)

        # Show total
        total_surf = font_medium.render(f"Total: ${total:.2f}", True, (255, 255, 255))
        screen.blit(total_surf, (panel_x + 10, panel_y - 30))

        # Draw top bar
        topbar.draw(screen)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
