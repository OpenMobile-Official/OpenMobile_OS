def greet_user(name):
    return f"Hello, {name}!" if name else "Hello!"
