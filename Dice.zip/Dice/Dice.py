import pygame
import sys
import random
from modules.top_bar import TopBarManager
from modules.keyboard import run_keyboard

def main():
    pygame.init()
    screen_width, screen_height = 480, 320
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Advanced Dice Roller")

    font_small = pygame.font.SysFont("Arial", 16)
    font_medium = pygame.font.SysFont("Arial", 20)
    font_instructions = pygame.font.SysFont("Arial", 14)

    topbar = TopBarManager(screen_width, screen_height, font_small, font_medium, app_key="diceapp")

    clock = pygame.time.Clock()

    # Button positions (left column)
    button_width, button_height = 140, 36
    button_x = 20
    roll_button_rect = pygame.Rect(button_x, 80, button_width, button_height)
    setdice_button_rect = pygame.Rect(button_x, 130, button_width, button_height)
    dicetype_button_rect = pygame.Rect(button_x, 180, button_width, button_height)

    button_color = (70, 130, 180)
    button_hover_color = (100, 160, 210)
    button_font = pygame.font.SysFont("Arial", 18)

    # Dice settings
    dice_count = 2
    dice_types = [4, 6, 8, 10, 12, 20]
    current_type_index = 1  # start with D6
    roll_history = []
    scroll_offset = 0

    instruction_text = "Dice App"

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            topbar.handle_event(event)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_clicked = True

            # Scroll with mouse wheel
            if event.type == pygame.MOUSEWHEEL:
                scroll_offset += event.y * 20
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(roll_history)*25 - 160))

            # Touch scrolling (drag)
            if event.type == pygame.MOUSEMOTION and event.buttons[0]:
                scroll_offset += event.rel[1]
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(roll_history)*25 - 160))

        topbar.update()

        # Background
        screen.fill((30, 30, 40))

        # Instruction text
        instruction_surf = font_instructions.render(instruction_text, True, (255, 255, 255))
        screen.blit(instruction_surf, (20, 50))

        # Roll Dice button
        if roll_button_rect.collidepoint(mouse_pos):
            pygame.draw.rect(screen, button_hover_color, roll_button_rect, border_radius=8)
            if mouse_clicked:
                dice_values = [random.randint(1, dice_types[current_type_index]) for _ in range(dice_count)]
                roll_history.append(dice_values)
                if len(roll_history) > 100:
                    roll_history.pop(0)
        else:
            pygame.draw.rect(screen, button_color, roll_button_rect, border_radius=8)

        roll_text = button_font.render("Roll Dice", True, (255, 255, 255))
        screen.blit(roll_text, roll_text.get_rect(center=roll_button_rect.center))

        # Set Dice Count button
        if setdice_button_rect.collidepoint(mouse_pos):
            pygame.draw.rect(screen, button_hover_color, setdice_button_rect, border_radius=8)
            if mouse_clicked:
                new_count = run_keyboard()
                try:
                    dice_count = max(1, min(10, int(new_count)))
                except:
                    pass
        else:
            pygame.draw.rect(screen, button_color, setdice_button_rect, border_radius=8)

        setdice_text = button_font.render(f"Dice: {dice_count}", True, (255, 255, 255))
        screen.blit(setdice_text, setdice_text.get_rect(center=setdice_button_rect.center))

        # Change Dice Type button
        if dicetype_button_rect.collidepoint(mouse_pos):
            pygame.draw.rect(screen, button_hover_color, dicetype_button_rect, border_radius=8)
            if mouse_clicked:
                current_type_index = (current_type_index + 1) % len(dice_types)
        else:
            pygame.draw.rect(screen, button_color, dicetype_button_rect, border_radius=8)

        dicetype_text = button_font.render(f"Dice Type: D{dice_types[current_type_index]}", True, (255, 255, 255))
        screen.blit(dicetype_text, dicetype_text.get_rect(center=dicetype_button_rect.center))

        # Results panel (right side)
        panel_x = 180
        panel_y = 80
        panel_width = screen_width - panel_x - 20
        panel_height = screen_height - panel_y - 20
        pygame.draw.rect(screen, (40, 40, 60), (panel_x, panel_y, panel_width, panel_height), border_radius=6)

        # Scrollable history inside panel
        history_y = panel_y + 10 + scroll_offset
        for i, dice_values in enumerate(roll_history):
            roll_text = f"Roll {i+1}: " + ", ".join(str(v) for v in dice_values)
            roll_surf = font_small.render(roll_text, True, (200, 200, 200))
            screen.blit(roll_surf, (panel_x + 10, history_y))
            history_y += 22

        # Draw top bar
        topbar.draw(screen)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
