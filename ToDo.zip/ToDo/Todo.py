import pygame
import sys
import os
from modules.top_bar import TopBarManager
from modules.keyboard import run_keyboard

SAVE_FILE = "tasks.txt"
TUTORIAL_FILE = "tutorial_seen.txt"

def draw_gradient_rect(surface, rect, color1, color2):
    """Draw a vertical gradient rectangle."""
    x, y, w, h = rect
    for i in range(h):
        ratio = i / h
        r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
        g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
        b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
        pygame.draw.line(surface, (r, g, b), (x, y + i), (x + w, y + i))

def load_tasks():
    tasks = []
    if os.path.exists(SAVE_FILE):
        with open(SAVE_FILE, "r", encoding="utf-8") as f:
            for line in f:
                parts = line.strip().split("|")
                if len(parts) == 2:
                    text, completed = parts
                    tasks.append([text, completed == "1"])
    return tasks

def save_tasks(tasks):
    with open(SAVE_FILE, "w", encoding="utf-8") as f:
        for text, completed in tasks:
            f.write(f"{text}|{'1' if completed else '0'}\n")

def tutorial_already_seen():
    return os.path.exists(TUTORIAL_FILE)

def mark_tutorial_seen():
    with open(TUTORIAL_FILE, "w") as f:
        f.write("seen")

def main():
    pygame.init()
    screen_width, screen_height = 480, 320
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Modern To-Do List")

    font_small = pygame.font.SysFont("Arial", 18)
    font_medium = pygame.font.SysFont("Arial", 22)
    font_title = pygame.font.SysFont("Arial", 26, bold=True)

    topbar = TopBarManager(screen_width, screen_height, font_small, font_medium, app_key="todoapp")

    clock = pygame.time.Clock()

    # Button properties
    button_width = 180
    button_height = 50
    button_x = 20
    button_y = 80
    add_button_rect = pygame.Rect(button_x, button_y, button_width, button_height)
    button_font = pygame.font.SysFont("Arial", 22)

    # Task storage
    tasks = load_tasks()
    scroll_offset = 0

    # Tutorial overlay (only once)
    show_tutorial = not tutorial_already_seen()

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            topbar.handle_event(event)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_clicked = True

            # Scroll tasks with mouse wheel
            if event.type == pygame.MOUSEWHEEL:
                scroll_offset += event.y * 20
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(tasks)*30 - 160))

            # Touch drag scrolling
            if event.type == pygame.MOUSEMOTION and event.buttons[0]:
                scroll_offset += event.rel[1]
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(tasks)*30 - 160))

        topbar.update()

        # Gradient background
        draw_gradient_rect(screen, (0, 0, screen_width, screen_height), (25, 25, 60), (60, 60, 120))

        # Title
        title_surf = font_title.render("✅ Modern To-Do List", True, (255, 255, 255))
        screen.blit(title_surf, (20, 20))

        # Add Task button
        draw_gradient_rect(screen, add_button_rect, (50, 150, 250), (30, 100, 200))
        pygame.draw.rect(screen, (255, 255, 255), add_button_rect, 2, border_radius=12)

        if add_button_rect.collidepoint(mouse_pos) and mouse_clicked:
            new_task = run_keyboard()
            if new_task.strip():
                tasks.append([new_task.strip(), False])
                save_tasks(tasks)

        text_surf = button_font.render("Add Task", True, (255, 255, 255))
        text_rect = text_surf.get_rect(center=add_button_rect.center)
        screen.blit(text_surf, text_rect)

        # Tasks panel (right side)
        panel_x = 220
        panel_y = 80
        panel_width = screen_width - panel_x - 20
        panel_height = screen_height - panel_y - 20
        panel_rect = pygame.Rect(panel_x, panel_y, panel_width, panel_height)

        draw_gradient_rect(screen, panel_rect, (40, 40, 70), (70, 70, 120))
        pygame.draw.rect(screen, (255, 255, 255), panel_rect, 2, border_radius=8)

        # Clip drawing to panel
        screen.set_clip(panel_rect)

        # Display tasks (scrollable inside box only)
        history_y = panel_y + 10 + scroll_offset
        for i, (task_text, completed) in enumerate(tasks):
            color = (150, 255, 150) if completed else (230, 230, 230)
            task_surf = font_small.render(f"{i+1}. {task_text}", True, color)
            task_rect = task_surf.get_rect(topleft=(panel_x + 10, history_y))
            screen.blit(task_surf, task_rect)

            # X button for delete
            x_rect = pygame.Rect(panel_x + panel_width - 30, history_y, 20, 20)
            pygame.draw.rect(screen, (200, 50, 50), x_rect, border_radius=4)
            x_text = font_small.render("X", True, (255, 255, 255))
            x_text_rect = x_text.get_rect(center=x_rect.center)
            screen.blit(x_text, x_text_rect)

            # Interactions
            if mouse_clicked:
                if task_rect.collidepoint(mouse_pos):
                    tasks[i][1] = not tasks[i][1]  # toggle completion
                    save_tasks(tasks)
                elif x_rect.collidepoint(mouse_pos):
                    tasks.pop(i)  # delete task
                    save_tasks(tasks)

            history_y += 30

        # Reset clipping
        screen.set_clip(None)

        # Tutorial overlay (only once)
        if show_tutorial:
            overlay = pygame.Surface((screen_width, screen_height), pygame.SRCALPHA)
            overlay.fill((0, 0, 0, 180))
            screen.blit(overlay, (0, 0))

            tutorial_lines = [
                "📖 Tutorial:",
                "- Tap 'Add Task' to create a new task",
                "- Tap a task to mark it complete",
                "- Tap the ❌ button to delete a task",
                "- Swipe up/down to scroll the list",
                "Tap anywhere to close this tutorial"
            ]
            y = 60
            for line in tutorial_lines:
                tut_surf = font_medium.render(line, True, (255, 255, 255))
                screen.blit(tut_surf, (40, y))
                y += 40

            if mouse_clicked:
                show_tutorial = False
                mark_tutorial_seen()

        # Draw top bar
        topbar.draw(screen)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
