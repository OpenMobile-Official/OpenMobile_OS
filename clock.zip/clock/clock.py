import pygame
import sys
import time
from modules.top_bar import TopBarManager  # Keep your top bar module if you want it

def main():
    pygame.init()
    screen_width, screen_height = 480, 320
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Digital Clock")

    # Fonts
    font_large = pygame.font.SysFont("Arial", 72, bold=True)
    font_small = pygame.font.SysFont("Arial", 18)
    font_medium = pygame.font.SysFont("Arial", 22)

    # Top bar (optional)
    topbar = TopBarManager(screen_width, screen_height, font_small, font_medium, app_key="clockapp")

    clock = pygame.time.Clock()

    # Instruction text


    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            topbar.handle_event(event)

        topbar.update()

        # Draw background
        screen.fill((30, 30, 30))  # Dark background for contrast

        # Draw instruction text
        


        # Get current time
        current_time = time.strftime("%H:%M:%S")
        time_surf = font_large.render(current_time, True, (0, 255, 180))  # Aqua color
        time_rect = time_surf.get_rect(center=(screen_width // 2, screen_height // 2))
        screen.blit(time_surf, time_rect)

        # Draw top bar
        topbar.draw(screen)

        pygame.display.flip()
        clock.tick(60)  # Update once per second

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
