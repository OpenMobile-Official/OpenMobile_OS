import pygame
import sys
import time
from modules.top_bar import TopBarManager

def draw_gradient_rect(surface, rect, color1, color2):
    """Draw a vertical gradient rectangle."""
    x, y, w, h = rect
    for i in range(h):
        ratio = i / h
        r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
        g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
        b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
        pygame.draw.line(surface, (r, g, b), (x, y + i), (x + w, y + i))

def format_time(seconds):
    """Format time as MM:SS.mmm"""
    minutes = int(seconds // 60)
    secs = int(seconds % 60)
    millis = int((seconds * 1000) % 1000)
    return f"{minutes:02}:{secs:02}.{millis:03}"

def main():
    pygame.init()
    screen_width, screen_height = 480, 320
    screen = pygame.display.set_mode((screen_width, screen_height))
    pygame.display.set_caption("Stopwatch App")

    font_small = pygame.font.SysFont("Arial", 16)
    font_medium = pygame.font.SysFont("Arial", 22)
    font_title = pygame.font.SysFont("Arial", 26, bold=True)

    topbar = TopBarManager(screen_width, screen_height, font_small, font_medium, app_key="stopwatch")

    clock = pygame.time.Clock()

    # Buttons (left side)
    button_width, button_height = 140, 36
    button_x = 20
    start_button_rect = pygame.Rect(button_x, 80, button_width, button_height)
    stop_button_rect = pygame.Rect(button_x, 130, button_width, button_height)
    reset_button_rect = pygame.Rect(button_x, 180, button_width, button_height)
    lap_button_rect = pygame.Rect(button_x, 230, button_width, button_height)

    button_font = pygame.font.SysFont("Arial", 18)

    # Stopwatch state
    running_timer = False
    start_time = 0
    elapsed_time = 0
    laps = []  # store (lap_time, total_time)
    scroll_offset = 0

    running = True
    while running:
        mouse_pos = pygame.mouse.get_pos()
        mouse_clicked = False

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            topbar.handle_event(event)

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                mouse_clicked = True

            # Scroll laps with mouse wheel
            if event.type == pygame.MOUSEWHEEL:
                scroll_offset += event.y * 20
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(laps)*25 - 120))

            # Touch drag scrolling
            if event.type == pygame.MOUSEMOTION and event.buttons[0]:
                scroll_offset += event.rel[1]
                scroll_offset = max(min(scroll_offset, 0), -max(0, len(laps)*25 - 120))

        topbar.update()

        # Gradient background
        draw_gradient_rect(screen, (0, 0, screen_width, screen_height), (25, 25, 60), (60, 60, 120))

        # Title
        title_surf = font_title.render("⏱ Stopwatch", True, (255, 255, 255))
        screen.blit(title_surf, (20, 20))

        # Buttons helper
        def draw_button(rect, text, action=None):
            draw_gradient_rect(screen, rect, (50, 150, 250), (30, 100, 200))
            pygame.draw.rect(screen, (255, 255, 255), rect, 2, border_radius=10)

            if rect.collidepoint(mouse_pos):
                if mouse_clicked and action:
                    action()
                # Hover overlay
                pygame.draw.rect(screen, (255, 255, 255), rect, 2, border_radius=10)

            txt = button_font.render(text, True, (255, 255, 255))
            screen.blit(txt, txt.get_rect(center=rect.center))

        # Button actions
        def start_action():
            nonlocal running_timer, start_time
            if not running_timer:
                running_timer = True
                start_time = time.time() - elapsed_time

        def stop_action():
            nonlocal running_timer, elapsed_time
            if running_timer:
                running_timer = False
                elapsed_time = time.time() - start_time

        def reset_action():
            nonlocal running_timer, elapsed_time, laps
            running_timer = False
            elapsed_time = 0
            laps = []

        def lap_action():
            nonlocal laps, elapsed_time
            total_time = elapsed_time
            lap_time = total_time - (laps[-1][1] if laps else 0)
            laps.append((lap_time, total_time))

        draw_button(start_button_rect, "Start", start_action)
        draw_button(stop_button_rect, "Stop", stop_action)
        draw_button(reset_button_rect, "Reset", reset_action)
        draw_button(lap_button_rect, "Lap", lap_action)

        # Update elapsed time
        if running_timer:
            elapsed_time = time.time() - start_time

        # Results panel (right side)
        panel_x = 180
        panel_y = 80
        panel_width = screen_width - panel_x - 20
        panel_height = screen_height - panel_y - 20
        panel_rect = pygame.Rect(panel_x, panel_y, panel_width, panel_height)

        draw_gradient_rect(screen, panel_rect, (40, 40, 70), (70, 70, 120))
        pygame.draw.rect(screen, (255, 255, 255), panel_rect, 2, border_radius=8)

        # Display elapsed time (always visible, not clipped)
        time_text = format_time(elapsed_time)
        time_surf = font_medium.render(f"Time: {time_text}", True, (255, 255, 255))
        screen.blit(time_surf, (panel_x + 20, panel_y + 20))

        # Clip drawing only to lap list area (below time)
        laps_area = pygame.Rect(panel_x, panel_y + 60, panel_width, panel_height - 60)
        screen.set_clip(laps_area)

        # Display laps (scrollable inside box only)
        history_y = panel_y + 60 + scroll_offset
        for i, (lap_time, total_time) in enumerate(laps):
            lap_text = f"Lap {i+1}: {format_time(lap_time)} | Total: {format_time(total_time)}"
            lap_surf = font_small.render(lap_text, True, (230, 230, 230))
            screen.blit(lap_surf, (panel_x + 20, history_y))
            history_y += 22

        # Reset clipping
        screen.set_clip(None)

        # Draw top bar
        topbar.draw(screen)

        pygame.display.flip()
        clock.tick(60)

    pygame.quit()
    sys.exit()

if __name__ == "__main__":
    main()
