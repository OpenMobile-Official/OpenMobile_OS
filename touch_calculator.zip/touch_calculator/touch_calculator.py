import pygame
import sys
import math
import os
from modules.top_bar import TopBarManager  # ✅ Import the TopBarManager

pygame.init()

# --- Screen setup ---
WIDTH, HEIGHT = 480, 320
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Touch Calculator")
clock = pygame.time.Clock()

# --- Fonts ---
FONT = pygame.font.SysFont("Arial", 18)
FONT_SMALL = pygame.font.SysFont("Arial", 14)
FONT_MEDIUM = pygame.font.SysFont("Arial", 18)

# --- Modes and State ---
MODES = ["Normal", "Scientific", "Convert"]
mode_index = 0
theme = "dark"
expression = ""
result = ""
history = []

# --- File for history (store alongside this script) ---
APP_DIR = os.path.dirname(os.path.abspath(__file__))
HISTORY_FILE = os.path.join(APP_DIR, "calc_history.txt")

if os.path.exists(HISTORY_FILE):
    with open(HISTORY_FILE, "r") as f:
        history = [line.strip() for line in f.readlines()]

# --- Themes ---
THEMES = {
    "dark": {
        "bg": (30, 30, 30),
        "text": (255, 255, 255),
        "input_bg": (50, 50, 60),
        "button": (70, 130, 180),
        "hover": (100, 160, 210)
    },
    "light": {
        "bg": (230, 230, 230),
        "text": (20, 20, 20),
        "input_bg": (255, 255, 255),
        "button": (180, 200, 220),
        "hover": (200, 220, 240)
    }
}

# --- Button Layouts ---
base_buttons = [
    ["7", "8", "9", "/"],
    ["4", "5", "6", "*"],
    ["1", "2", "3", "-"],
    ["0", ".", "=", "+"],
    ["C", "", "", ""]
]

scientific_buttons = [
    ["sin", "cos", "tan", "sqrt"],
    ["log", "exp", "(", ")"],
    ["pi", "e", "", ""]
]

convert_buttons = [
    ["C→F", "F→C", "cm→in", "in→cm"],
    ["kg→lb", "lb→kg", "", ""]
]


def get_buttons():
    if MODES[mode_index] == "Normal":
        return base_buttons
    elif MODES[mode_index] == "Scientific":
        return base_buttons + scientific_buttons
    else:
        return base_buttons + convert_buttons


def draw_text(text, x, y, center=False):
    color = THEMES[theme]["text"]
    surf = FONT.render(text, True, color)
    rect = surf.get_rect()
    if center:
        rect.center = (x, y)
    else:
        rect.topleft = (x, y)
    screen.blit(surf, rect)


def evaluate_expression(expr, mode):
    try:
        if mode == "Normal":
            return str(eval(expr))
        elif mode == "Scientific":
            expr = expr.replace("sin", "math.sin")
            expr = expr.replace("cos", "math.cos")
            expr = expr.replace("tan", "math.tan")
            expr = expr.replace("log", "math.log")
            expr = expr.replace("exp", "math.exp")
            expr = expr.replace("sqrt", "math.sqrt")
            expr = expr.replace("pi", str(math.pi))
            expr = expr.replace("e", str(math.e))
            return str(eval(expr))
        elif mode == "Convert":
            if "C→F" in expr:
                val = float(expr.replace("C→F", ""))
                return str(round(val * 9/5 + 32, 2))
            elif "F→C" in expr:
                val = float(expr.replace("F→C", ""))
                return str(round((val - 32) * 5/9, 2))
            elif "cm→in" in expr:
                val = float(expr.replace("cm→in", ""))
                return str(round(val / 2.54, 2))
            elif "in→cm" in expr:
                val = float(expr.replace("in→cm", ""))
                return str(round(val * 2.54, 2))
            elif "kg→lb" in expr:
                val = float(expr.replace("kg→lb", ""))
                return str(round(val * 2.20462, 2))
            elif "lb→kg" in expr:
                val = float(expr.replace("lb→kg", ""))
                return str(round(val / 2.20462, 2))
            else:
                return "Invalid"
    except Exception:
        return "Error"


def draw_buttons(buttons):
    rows = len(buttons)
    cols = max(len(row) for row in buttons)
    btn_w = 330 // cols
    btn_h = (HEIGHT - 140) // rows

    for row_idx, row in enumerate(buttons):
        for col_idx, label in enumerate(row):
            x = col_idx * btn_w
            y = 140 + row_idx * btn_h
            rect = pygame.Rect(x + 5, y + 5, btn_w - 10, btn_h - 10)
            color = THEMES[theme]["hover"] if rect.collidepoint(pygame.mouse.get_pos()) else THEMES[theme]["button"]
            pygame.draw.rect(screen, color, rect, border_radius=8)
            if label:
                draw_text(label, rect.centerx, rect.centery, center=True)


def handle_button(label):
    global expression, result, history
    if label == "=":
        result = evaluate_expression(expression, MODES[mode_index])
        history.append(f"{expression} = {result}")
        with open(HISTORY_FILE, "a") as f:
            f.write(f"{expression} = {result}\n")
    elif label == "C":
        expression = ""
        result = ""
    else:
        expression += label


# --- Initialize Top Bar ---
top_bar = TopBarManager(WIDTH, HEIGHT, FONT_SMALL, FONT_MEDIUM, "Touch Calculator")

# --- Main Loop ---
running = True
while running:
    screen.fill(THEMES[theme]["bg"])

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        # --- Let top bar handle drag/close ---
        top_bar.handle_event(event)

        if event.type == pygame.MOUSEBUTTONDOWN:
            if mode_btn.collidepoint(event.pos):
                mode_index = (mode_index + 1) % len(MODES)
                expression = ""
                result = ""
            elif theme_btn.collidepoint(event.pos):
                theme = "light" if theme == "dark" else "dark"
            elif clear_btn.collidepoint(event.pos):
                history = []
                open(HISTORY_FILE, "w").close()
            else:
                buttons = get_buttons()
                rows = len(buttons)
                cols = max(len(row) for row in buttons)
                btn_w = 330 // cols
                btn_h = (HEIGHT - 140) // rows
                for row_idx, row in enumerate(buttons):
                    for col_idx, label in enumerate(row):
                        x = col_idx * btn_w
                        y = 140 + row_idx * btn_h
                        rect = pygame.Rect(x + 5, y + 5, btn_w - 10, btn_h - 10)
                        if rect.collidepoint(event.pos) and label:
                            handle_button(label)

    # --- Update top bar animation ---
    top_bar.update()

    # --- Input/output box ---
    pygame.draw.rect(screen, THEMES[theme]["input_bg"], (10, 40, 310, 40), border_radius=5)
    draw_text(expression, 20, 50)
    draw_text(result, 20, 90)

    # --- Mode toggle ---
    mode_btn = pygame.Rect(WIDTH - 160, 10, 150, 30)
    pygame.draw.rect(screen, THEMES[theme]["button"], mode_btn, border_radius=5)
    draw_text(f"Mode: {MODES[mode_index]}", mode_btn.centerx, mode_btn.centery, center=True)

    # --- Theme toggle ---
    theme_btn = pygame.Rect(10, 10, 100, 30)
    pygame.draw.rect(screen, THEMES[theme]["button"], theme_btn, border_radius=5)
    draw_text(f"Theme: {theme}", theme_btn.centerx, theme_btn.centery, center=True)

    # --- Clear history button ---
    clear_btn = pygame.Rect(WIDTH - 160, HEIGHT - 40, 150, 30)
    pygame.draw.rect(screen, THEMES[theme]["button"], clear_btn, border_radius=5)
    draw_text("Clear History", clear_btn.centerx, clear_btn.centery, center=True)

    # --- History panel ---
    pygame.draw.rect(screen, THEMES[theme]["input_bg"], (WIDTH - 160, 40, 150, HEIGHT - 90), border_radius=5)
    draw_text("History:", WIDTH - 150, 50)
    recent = history[-10:] if len(history) > 10 else history
    for i, entry in enumerate(recent):
        draw_text(entry, WIDTH - 150, 70 + i * 20)

    # --- Draw buttons ---
    draw_buttons(get_buttons())

    # --- Draw top bar ---
    top_bar.draw(screen)

    pygame.display.flip()
    clock.tick(60)

pygame.quit()
sys.exit()
